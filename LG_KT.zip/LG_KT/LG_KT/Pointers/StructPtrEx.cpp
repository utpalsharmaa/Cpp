#include<iostream>
using namespace std;
//structure decleration for vertices
struct point{
    int x;
    int y;

};

// structure decleration for square

struct square
{
   point left;
   point right;
};

//Function to calculate area of the given Square
void area_square(struct square s){
    int area=(s.right.x)*(s.left.y);
    cout<<area<<endl;
}

int main() {
struct square s= {{4,4},{4,4}};
area_square(s);
    return 0;
}