#include<iostream>
using namespace std;
struct point{
    int value;
};

int main() {
    struct point g;
    struct point* ptr =&g;
    return 0;
}