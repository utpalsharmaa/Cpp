#include<iostream>
using namespace std;
const int a=10;
const int b=5;

int mul(){
    return a*b;
}

void display(int (*funcptr) ()){
    cout<<funcptr();
}

int main() {
    display(mul);

    return 0;
}