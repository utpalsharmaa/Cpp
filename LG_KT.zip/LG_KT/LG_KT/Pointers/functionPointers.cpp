#include<iostream>
using namespace std;

int add(int a,int b){
    return a+b;
}
int main() {
    int (*func)(int ,int);
    //  func is pointing to the addTwoValues function
    func=add;
    cout<<func(5,6);
    return 0;
}

