#include<iostream>
using namespace std;

 void fun(int a,int b){
        int res=a+b;
        cout<<res;
    }
int main() {
    int x=5;
    int y=6;
    fun(x,y);
   

    return 0;
}