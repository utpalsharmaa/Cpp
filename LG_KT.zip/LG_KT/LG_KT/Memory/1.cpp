#include<iostream>
using namespace std;
class Person{
    public:
    string name;
    int age;
    void display(){
        cout<<"name "<<name<<endl<<"age "<<age<<endl;
    }
};
int main() {
    Person* personptr=new Person;
    personptr->name="utpal";
    personptr->age=23;
    personptr->display();
    delete personptr;

    return 0;
}