#include<iostream>
#include<cstring>
using namespace std;

// #include <cstring>
// void* memcpy(void* dest, const void* src, size_t count);

// dest: A pointer to the destination array where the content is to be copied.
// src: A pointer to the source of data to be copied.
// count: The number of bytes to copy.

int main() {
    int source[]={1,2,3,4};
    int n=sizeof(source)/sizeof(source[0]);
    int destination[5];

    memcpy(destination, source, sizeof(source));

    for(int i=0;i<n;i++){
        cout<<destination[i]<<endl;
    }

    return 0;
}

// #include <iostream>
// #include <string>
// #include <cstring>

// int main() {
//    const char s[]="utpal";
//    char s1[10];

//    memcpy(s1,s,sizeof(s));

//    cout<<s1;
// }
