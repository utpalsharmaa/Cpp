#include<iostream>
using namespace std;

int main() {
    int* dynamicInt =new int;
    *dynamicInt=24;
    cout<<"Value on heap: "<<*dynamicInt<<endl;
    delete dynamicInt;

    return 0;
}
