#include<iostream>
using namespace std;
class base{
    public:
    virtual void display()=0;
};
class derived:public base{
    public:
    void display(){
        cout<<"This is base class"<<endl;
    }

};
int main() {
    base* baseptr;

    derived d;
    baseptr=&d;
    baseptr->display();


    return 0;
}
