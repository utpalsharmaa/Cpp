// #include<iostream>
// using namespace std;
// class Sample{
//     int x;
//     public:
//     Sample(int x): x(x){};

//     void operator++(){
//         ++x;
//     }

//     void display(){
//         cout<<x;
//     }
// };
// int main() {
//     Sample s(20);
//     ++s;
//     s.display();

//     return 0;
// }

// #include<iostream>
// using namespace std;
// class Complex{
//     int real;
//     int imag;
//     public:
//     Complex(int r = 0, int i = 0)
//     {
//         real = r;
//         imag = i;
//     }
//     Complex operator+(Complex const& obj){
//         Complex res;
//         res.real=real+obj.real;
//         res.imag=imag+obj.imag;
//         return res;
//     }
//     void display(){
//         cout<<real<<"+i"<<imag<<endl;
//     }
// };
// int main() {
//     Complex c1(10,5), c2(2,4);
//     Complex c3=c1+c2;
//     c3.display();

//     return 0;
// }

#include<iostream>
using namespace std;
class Complex{
    int real;
    int imag;
    public:
    Complex(int r=0,int i=0){
        real=r;
        imag=i;
    }
 
    Complex operator+(Complex const& obj){
        Complex res;
        res.real=real+obj.real;
        res.imag=imag+obj.imag;
        return res;

    }
    void display(){
        cout<<real<<"+i"<<imag;
    }
    
};
int main() {
    Complex c1(3,4),c2(5,3);
    Complex c3=c1+c2;
    c3.display();

    return 0;
}