#include<iostream>
#include<unordered_map>
using namespace std;
int main(){
    unordered_map<string,int>umap;

    umap["one"]=1;
    umap["Two"]=2;
    umap["three"]=3;

    cout<<umap["one"]<<endl;

// Returns an iterator to the element with the specified key
    if(umap.find("four")!=umap.end()){
        cout<<"key found";
    }
    else{
        cout<<"key not found"<<endl;
    }
 // Inserts a new element using the key-value pair
    umap.insert(make_pair("four",4));


// Accesses the element with the specified key
    int value=umap.at("Two");
    cout<<"Value at Two is: "<<value<<endl;

//    delete with specific key
    umap.erase("Two");

// delete all
    // umap.clear();
    

// Iterating through the unordered_map

    for(const auto& pair:umap){
        cout << pair.first << ": " << pair.second<<endl;
    }

   
     
// Returns the number of elements with the specified key

    if (umap.count("Two") > 0) {
    cout << "Key 2 exists." << endl;
}
//  Returns the number of elements in the unordered_map
    cout<<umap.size()<<endl;

// Returns true if the unordered_map is empty
if (umap.empty()) {
    cout << "The unordered_map is empty." << std::endl;
}
else{
    cout<<"The unordered_map is not empty";
}


}
