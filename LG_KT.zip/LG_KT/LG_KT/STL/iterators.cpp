#include<iostream>
#include<vector>
using namespace std;

int main() {
    vector<int> v1 ={1,2,3,4,5};

    for(vector<int>::iterator it=v1.begin(); it!=v1.end();it++){
        cout<<*it<<" "; 

    }
    

    return 0;
}