#include<iostream>
#include<queue>
using namespace std;

int main() {
    queue<int>q;

    q.push(1);
    q.push(2);
    for(int i=3;i<10;i++){
        q.push(i);
    }
    cout<<"Size of queue is:"<<q.size()<<endl;
    q.pop();
    cout<<"Size of queue is:"<<q.size()<<endl;
    
    cout<<q.front()<<endl;

    while(!q.empty()){
        cout<<q.front()<<" ";
        q.pop();
    }
    cout<<endl;

   
    if(q.empty()){
        cout<<"queue is empty";
    }
    else{
        cout<<"queue isn't empty";
    }

    return 0;
}