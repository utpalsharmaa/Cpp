#include<iostream>
using namespace std;

class Person{
    public:
    string name;
    int age;
    Person(){
        name="Utpal";
        age=23;
        cout<<"Person"<<name<<"Constructor is callled"<<endl;
    }
    void display(){
            cout<<"Person name is "<<name<<endl<<" Person age is "<<age<<endl;
        }
};
int main() {
    Person p;
    p.display();

    return 0;
}