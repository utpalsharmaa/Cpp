#include <iostream>

class OuterClass {
private:
    int outerData;

public:
    OuterClass(int data) : outerData(data) {}

    // Nested Class (Inner Class)
    class NestedClass {
    public:
        void displayOuterData(const OuterClass& outerObj) {
            std::cout << "Outer Data: " << outerObj.outerData << std::endl;
        }
    };
};

int main() {
    // Creating an instance of the outer class
    OuterClass outerObj(42);

    // Creating an instance of the nested class
    OuterClass::NestedClass nestedObj;

    // Accessing outer class data from the nested class
    nestedObj.displayOuterData(outerObj);

    return 0;
}


// #include<iostream>
// using namespace std;
// class parent{
//     int age;
//     public:
//     parent(int a){
//         age=a;
//     }
//     class nestparent{
//         public:
//         void dispParent(const parent& p){
//             cout<<p.age;
//         }
//     };
// };
// int main(){
//     parent p(45);
//     parent::nestparent n;
//     n.dispParent(p);
// }





















