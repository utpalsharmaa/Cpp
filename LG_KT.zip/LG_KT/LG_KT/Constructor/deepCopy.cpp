#include<iostream>
using namespace std;

class Person {
private:
    string name;
    int* agePtr;

public:
    // Constructor to initialize Person with a name and age pointer
    Person(string n, int* a) {
        name = n;
        agePtr = new int;  // Allocate memory for the age pointer

    }

    // Copy constructor to perform deep copy
    Person(const Person& other) {
        name = other.name;
        agePtr = new int;  // Allocate memory for the age pointer
        *agePtr = *(other.agePtr);  // Copy the value from the other object's age pointer
    }

    // Destructor to free the dynamically allocated memory
    ~Person() {
        delete agePtr;
    }

    // Function to display details
    void displayDetails() {
        cout << "Person name is " << name << endl << "Person Age is " << *agePtr << endl;
    }
};

int main() {
    // Create two Person objects with nullptr as age pointers
    Person P1("Utpal", nullptr);
    Person P2("Nayan", nullptr);

    // Perform deep copy using the copy constructor
    P1 = P2;

    // Display details of P1
    P1.displayDetails();

    return 0;
}
