#include<iostream>
using namespace std;
class Person{
    private:
    string name;
    int age;
    public:
    Person(string n,int a){
        name=n;
        age=a;
    }
    
    void displayDetails(){
        cout<<"Name of the person is:"<<name<<endl<<"Age of the Person is "<<age<<endl;
    }
    ~Person(){
        cout<<"Destructor is called"<<endl;
    }

};
int main() {
    Person P1("Utpal",24);
    Person P2("Nayan",25);

    P1=P2;

    P1.displayDetails();


    return 0;
}