#include<iostream>
using namespace std;
class Person{
    public:
    string name;
    int age;
    Person(string n,int a){
        name=n;
        age=a;

        cout<<"Constructor is called for Name "<<name<<endl;
        
    }
    void display(){
        cout<<"Name "<<name<<endl<<"Age "<<age<<endl;

    }

};
int main() {
    Person P("Utpal",23);
    P.display();


    return 0;
}