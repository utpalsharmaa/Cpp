#include<iostream>
using namespace std;

int main() {
    char* mess="Hello word";
    char* ptr=mess;

    while(*ptr!='\0'){
        cout<<*ptr;
        ++ptr;
    }

    return 0;
}
