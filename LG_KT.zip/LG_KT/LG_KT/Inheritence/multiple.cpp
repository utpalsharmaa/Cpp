#include<iostream>
using namespace std;
class gParent{
    public:
    void dispalyG(){
        cout<<"Grandparent is called"<<endl;
    }

};
class parent{
    public:
    void displayP(){
        cout<<"Parent is called"<<endl;
    }

};
class child:public gParent,public parent{
    public:
    void displayC(){
        cout<<"Parent is called"<<endl;
    }

};

int main() {
    child c;
    c.displayP();
    c.dispalyG();
    c.displayC();

    return 0;
}