#include<iostream>
using namespace std;
class Grandparent{
    public:
    void dispalyG(){
        cout<<"gparent is called"<<endl;
    }
};
class parent :virtual public Grandparent{
    public:
    void dispP(){
        cout<<"Parent is called"<<endl;
    }
};
class child:public parent{
    public:
    void dispaly(){
        cout<<"child is called"<<endl;
    }
};
int main() {
    child c;
    c.dispalyG();
    c.dispP();

    return 0;
}