#include<iostream>
using namespace std;
class parent{
    int age;
    public:
    void display(int a){
        age=a;
        cout<<"parent class is called and age is "<<age<<endl;
    }
};
class child:public parent{
    public:
    int x;
    // void disp(){
    //     cout<<"child is called"<<endl;
    // }
};
int main() {
    child c,c1;
    c.display(23);
    // c1.disp();

    return 0;
}