#include<iostream>
using namespace std;
class gParent{
    public:
    void dispalyG(){
        cout<<"Gparent is called"<<endl;
    }
};
class parent:public gParent{
    public:
    void displayP(){
        cout<<"parent is called"<<endl;
    }
};
class child:public parent{
    public:
    void displayP(){
        cout<<"parent is called"<<endl;
    }
};
int main() {
    child c;
    c.dispalyG();
    c.displayP();

    return 0;
}