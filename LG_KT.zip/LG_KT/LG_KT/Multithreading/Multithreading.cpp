#include<iostream>
#include<thread>
using namespace std;

// A dummy function
void fun(int z){
    for(int i=0;i<z;i++){
        cout<<"Thread using function pointer is callable"<<endl;
    }
}

// A callable object
class thread_obj{
    public:
    void operator()(int x){
        for(int i=0;i<x;i++){
            cout<<"Thread using function object is callable"<<endl;

        }
    }

};

// class definition
class Base{
    public:
    // non-static member function
    void fun(){
        cout<<"Thread using non-static member function as callable"<<endl;

    }
   
   //static member function
    static void fun1(){
        cout<<"Thread using static member function as callable"<<endl;

    }

};
int main() {
    cout<<"Thread 1, 2 and 3 Operating Independently"<<endl;

// This thread is launched by using
// function pointer as callable
    thread th1(fun ,3);

// This thread is launched by using
// function object as callable
    thread th2(thread_obj(), 3);

// Define a Lambda Expression
    auto f=[](int x){
        for(int i=0;i<x;i++){
            cout<<"Thread using Lambda expression as callable"<<endl;
        }
    };

// This thread is launched by using
// lambda expression as callable
    thread th3(f,3);

    Base b;

    thread th4(&Base::fun, &b);
    
    thread th5(&Base:: fun1);

// Wait for the threads to finish
// Wait for thread t1 to finish
    th1.join();

// Wait for thread t2 to finish
    th2.join();

// Wait for thread t3 to finish
    th3.join();
    
// Wait for thread t4 to finish
    th4.join();

// Wait for thread t5 to finish
    th5.join();


    return 0;
}