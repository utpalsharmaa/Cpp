#include<thread>
#include <iostream>
using namespace std;
void dispaly(int n){
    while(n-->0){
        cout<<n<<" ";
    }
    
}
int main()
{
    thread th1(dispaly,10);
    thread th2(dispaly,20);
    
    th1.join();
    cout<<endl;
    th2.join();

    return 0;
}

// output
// 9 8 7 6 5 4 3 2 1 0 
// 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0 