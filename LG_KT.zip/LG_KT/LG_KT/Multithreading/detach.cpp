#include <stdio.h>
#include<bits/stdc++.h>
using namespace std;

void fun(){
    for(int i=1;i<5;i++)
    cout<<"My name is Utpal"<<endl;
}
int main(){
    thread t1(fun);
    cout<<"Before"<<endl;
    t1.detach();
    cout<<"After"<<endl;
    this_thread::sleep_for(chrono::seconds(5));
    return 0;
}