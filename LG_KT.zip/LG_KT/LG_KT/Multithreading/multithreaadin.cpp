#include<iostream>
#include<thread>
#include<chrono>
using namespace std;
typedef unsigned long long ull;

ull oddSum=0;
ull evenSum=0;
void findEven(ull start,ull end){
    for(ull i=start; i<end; i++){
        if((i & 1)==0){
            evenSum+=i;
        }
    }
}
void findOdd(ull start,ull end){
    for(ull i=start; i<end; i++){
        if((i & 1)==1){
            oddSum+=i;
        }
    }
}

int main() {
    ull start=1;
    ull end=1900000000;
    
    auto startTime = chrono::high_resolution_clock::now();
    thread th1(findEven,start,end);
    thread th2(findOdd,start,end);
    th1.join();
    th2.join();
    // findEven(start,end);
    // findOdd(start,end);
    auto endTime = chrono::high_resolution_clock::now();

    auto duration = chrono::duration_cast<chrono::milliseconds>(endTime - startTime).count();

    cout<<"Even Sum "<<evenSum<<endl;
    cout<<"ODD Sum"<<oddSum<<endl;

    cout << "Execution Time: " << duration/1000<< " miliseconds" << endl;



    return 0;
}