#include <iostream>
#include <mutex>
#include <thread>

using namespace std;

int n = 0;
mutex nMutex;

void fun(int id) {
    for (int i = 0; i < 3; i++) {
        // lock_guard automatically locks the mutex and unlocks it when the guard goes out of scope
        lock_guard<mutex> lock(nMutex);
        ++n;
        cout << "Thread Id" << id << ", n: " << n << endl;
    }
}

int main() {
    thread th1(fun, 0);
    thread th2(fun, 1);

    th1.join();
    th2.join();

    return 0;
}

// #include<iostream>
// #include<mutex>
// #include<thread>
// using namespace std;

// int n=0;
// mutex nMutex;

// void fun(int id){
//     for(int i=0;i<3;i++){
//         nMutex.lock();
//         ++n;
//     cout<<"Thread Id"<<id<<",n:"<<n<<endl;
//     nMutex.unlock();
//     this_thread::sleep_for(chrono::microseconds(234));
//     }
// }

// int main() {
//     thread th1(fun,0);
//     thread th2(fun,1);

//     th1.join();
//     th2.join();
    

//     return 0;
// }