#include<iostream>
#include<thread>
#include<mutex>
using namespace std;
int mymoney=0;
std::mutex m;
void addMOney(){
    for(int i=0;i<100000;i++){
        if(m.try_lock()){
            ++mymoney;
        }
        m.unlock();
    }
}
int main() {
    thread th1(addMOney);
    thread th2(addMOney);
    th1.join();
    th2.join();
    
    cout<<"My money coud be: "<<mymoney;

    return 0;
} 