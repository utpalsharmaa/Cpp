#include<iostream>
#include<mutex>
#include<thread>
using namespace std;

int mymoney = 10;
// mutex variable
std::mutex m;

void addMoney(const char* ch) {
    // Lock the mutex to ensure thread safety
    std::lock_guard<std::mutex>lock(m);

    ++mymoney;
    cout << "Thread " << ch << " is called "<<mymoney << endl;
    // Mutex is automatically released when lock goes out of scope
}

int main() {
    thread th1(addMoney, "1");
    thread th2(addMoney, "2");
    
    th1.join();
    th2.join();

    return 0;
}
