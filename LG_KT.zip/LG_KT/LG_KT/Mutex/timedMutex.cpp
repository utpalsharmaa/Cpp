#include<iostream>
#include<thread>
#include<mutex>
using namespace std;
int mymoney=0;
std::timed_mutex m;
void addMOney(int i){
    if(m.try_lock_for(std::chrono::seconds(2))){
        ++mymoney;
        std::this_thread::sleep_for(std::chrono::seconds(1));
        cout<<"thread "<<i<<" is entered"<<endl;
        m.unlock();
    }
    else{
        cout<<"thread "<<i<<" couldn't entered"<<endl;
        
    }  
}
int main() {
    thread th1(addMOney,1);
    thread th2(addMOney,2);
    th1.join();
    th2.join();
    
    cout<<"My money coud be: "<<mymoney;

    return 0;
}