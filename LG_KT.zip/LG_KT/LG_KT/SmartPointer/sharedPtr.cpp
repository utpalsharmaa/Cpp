#include <iostream>
#include<memory>
using namespace std;
class Person{
    string name;
    int age;
    public:
    Person(string s,int a){
        name=s;
        age=a;
    }
    
    void display(){
        cout<<"name is:  "<<name<<" age is: "<<age<<endl;
    }
};
int main()
{
    shared_ptr<Person>p(new Person("utpal",25));
    // P->display();
    
    shared_ptr<Person>p2;


    p2 = p;
    
    p2->display();
    
    
    p->display
    
    // Reference Counter using the use_count() method. 
    cout<<p.use_count();

    return 0;
}
