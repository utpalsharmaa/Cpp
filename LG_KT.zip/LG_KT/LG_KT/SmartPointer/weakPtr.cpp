/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<memory>
using namespace std;
class Person{
    string name;
    int age;
    public:
    Person(string s,int a){
        name=s;
        age=a;
    }
    
    void display(){
        cout<<"name is:  "<<name<<" age is: "<<age<<endl;
    }
};
int main()
{
    shared_ptr<Person>p(new Person("utpal",25));
  
    
    weak_ptr<Person>p2(p);


    p->display();

    
    // Reference Counter using the use_count() method. 
    cout<<p.use_count();

    return 0;
}
