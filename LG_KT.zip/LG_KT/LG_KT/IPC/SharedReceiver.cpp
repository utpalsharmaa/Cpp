#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
using namespace std;
int main() {
    void *shared_memory;
    int shmid;

    shmid = shmget((key_t)1122, 1024, 0666);


    shared_memory = shmat(shmid, nullptr, 0); // process attached to shared memory segment

    cout << "Process attached at " << shared_memory <<endl; // this prints the address where the segment is attached

    cout << "Data read from shared memory is: " << reinterpret_cast<char *>(shared_memory) << std::endl;
    
    return 0;
}
