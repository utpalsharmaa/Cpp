#include<iostream>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
using namespace std;

#define MAX 100

//structure of a message queue
struct MaeesageQueue
{
    long msg_type;
    char msg_text[MAX];
}
message;


int main() {
    key_t key;
    int msgid;

    //ftok to generate unique key

    key=ftok("progfile",65);

    //msgget creates a message queue and returns idetifier

    msgid=msgget(key,0666 | IPC_CREAT);

    //writer process
    message.msg_type=1;
    cout<<"Writer Process\n";
    cout<<"Write Data:";

    cin.getline(message.msg_text,MAX);

    msgsnd(msgid,&message, sizeof(message),0);
    cout<<"Data Sent is:"<<message.msg_text<<endl;

    //Reader Process

    cout<<"Reader Process"<<endl;
    msgrcv(msgid, &message,sizeof(message),1,0);
    cout<<"Data Received is:"<<message.msg_text<<endl;

    // msgctl is use to Destroy message queue

    msgctl(msgid, IPC_RMID, nullptr);

    return 0;
}