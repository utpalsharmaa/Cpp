#include <iostream>
#include <sys/ipc.h>
#include <sys/shm.h>
using namespace std;

int main() {
    void *shared_memory;
    char buff[100];
    int shmid;

    shmid = shmget((key_t)1122, 1024, 0666 | IPC_CREAT); // creates shared memory segment with key 1122


    shared_memory = shmat(shmid, nullptr, 0); // process attached to shared memory segment

    cout << "Process attached at " << shared_memory << std::endl; // this prints the address where the segment is attached

    cout << "Enter some data to write to shared memory: ";
    cin.getline(buff, 100); // get some input from the user
    strcpy(reinterpret_cast<char *>(shared_memory), buff); // data written to shared memory

    cout << "You data send: " << reinterpret_cast<char *>(shared_memory) <<endl;

    return 0;

}
